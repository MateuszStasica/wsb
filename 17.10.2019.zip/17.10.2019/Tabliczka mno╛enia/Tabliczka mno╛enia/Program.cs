﻿using System;

namespace Tabliczka_mnożenia
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tabliczka mnożenia 10x10");

            int x = 1, y = 1;
            do
            {
                y = 1;
                do
                {
                    Console.Write("\t"+x*y);
                    y++;
                } while (y <= 10);

                Console.Write("\n");
                x++;
            } while (x <= 10);
        }
    }
}
