﻿using System;

namespace zadania_na_zajecia_laboratoryjne_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Oblicz wartość wyrażenia: (a^2+b)/(a+b)^2
            //dla zmiennych a i b typu float wczytywanych z klawiatury. Sprawdzić wykonalność obliczenia.

            
            double a1, b1;
            
            Console.WriteLine("Podaj wartość a: ");
            string a = Console.ReadLine();
            if (double.TryParse(a, out a1))
            {
                Console.WriteLine("Podaj wartość b: ");
                string b = Console.ReadLine();

                if (double.TryParse(b, out b1))
                {
                    Console.Write("Wartość wyrażęnia (a^2+b)/(a+b)^2 wynosi:"+(a1*a1+b1)/((a1+b1)*(a1+b1)));
                }
                else Console.WriteLine("Błędna wartość dla b!");
            }
            else Console.WriteLine("Błędna wartość dla a!");
            
        }
    }
}
