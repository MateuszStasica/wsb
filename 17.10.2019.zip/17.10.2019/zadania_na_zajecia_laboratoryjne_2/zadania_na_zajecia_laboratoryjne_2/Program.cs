﻿using System;

namespace zadania_na_zajecia_laboratoryjne_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Wykorzystując zmienne typu double obliczyć wartość wyrażenia wynoszącą:
            a^2+b dla c > 0
            a-b^2 dla c < 0
            1/a-b dla c=0
            Sprawdzić wykonalność obliczenia.*/

            Console.WriteLine("Podaj wartość a: ");
            double a;
            string a1 = Console.ReadLine();

            if (double.TryParse(a1, out a))
            {
                Console.WriteLine("Podaj wartość b: ");
                double b;
                string b1 = Console.ReadLine();
                if (double.TryParse(b1, out b))
                {
                    Console.WriteLine("Podaj wartość c: ");

                    string c1 = Console.ReadLine();
                    double c;
                    int wybór;

                    if (double.TryParse(c1, out c))
                    {
                        if (c < 0)
                            wybór = 1;
                        else if (c == 0)
                            wybór = 2;
                        else wybór = 3;

                        switch (wybór)
                        {
                            case 1:
                                Console.WriteLine("Dla c<0: " + (a - (b * b)));
                                break;
                            case 2:
                                Console.WriteLine("Dla c=0: " + (1 / (a - b)));
                                break;
                            case 3:
                                Console.WriteLine("Dla c>0: " + ((a*a)+b));
                                break;
                        }
                    }
                    else Console.WriteLine("Błędna wartość zmiennej c!");
                }
                else Console.WriteLine("Błędna wartość b!");
            }
            else Console.WriteLine("Błędna wartość a!");

            

            Console.ReadKey();
        }
    }
}
