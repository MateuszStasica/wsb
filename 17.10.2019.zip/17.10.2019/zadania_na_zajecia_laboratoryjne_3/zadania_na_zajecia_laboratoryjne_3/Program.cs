﻿using System;

namespace zadania_na_zajecia_laboratoryjne_3
{
    class Program
    {
        static void Main(string[] args)
        {

            //Napisać program obliczania największego wspólnego dzielnika dwóch dodatnich liczb całkowitych. Wykorzystać algorytm
            //Euklidesa nie używając operacji dzielenia.

            int a, b;

            Console.WriteLine("Podaj a: ");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Podaj b: ");
            b = int.Parse(Console.ReadLine());

            while (a != b)
            {
                if (a > b)
                    a -= b;
                else
                    b -= a;
            }
            Console.WriteLine("Największy wspólny dzielnik (NWD) to: " + a);
        }
    }
}
