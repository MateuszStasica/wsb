﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stasica_mateusz_kalkulator
{
    public partial class Kalkulator : Form
    {
        public Kalkulator()
        {
            InitializeComponent();
        }

        private void Kalkulator_Load(object sender, EventArgs e)
        {

        }

        string LiczbaPierwsza, LiczbaDruga;
        char RodzajDzialania = ' ';

        private void b1_Click(object sender, EventArgs e)
        {
            dzialanie(1);
        }

        private void b2_Click(object sender, EventArgs e)
        {
            dzialanie(2);
        }

        private void b3_Click(object sender, EventArgs e)
        {
            dzialanie(3);
        }

        private void b4_Click(object sender, EventArgs e)
        {
            dzialanie(4);
        }

        private void b5_Click(object sender, EventArgs e)
        {
            dzialanie(5);
        }

        private void b6_Click(object sender, EventArgs e)
        {
            dzialanie(6);
        }

        private void b7_Click(object sender, EventArgs e)
        {
            dzialanie(7);
        }

        private void b8_Click(object sender, EventArgs e)
        {
            dzialanie(8);
        }

        private void b9_Click(object sender, EventArgs e)
        {
            dzialanie(9);
        }

        private void b0_Click(object sender, EventArgs e)
        {
            dzialanie(0);
        }

        private void bDodawanie_Click(object sender, EventArgs e)
        {
            RodzajDzialania = '+';
            tbWynik.Text = "+";
        }

        private void bOdejmowanie_Click(object sender, EventArgs e)
        {
            RodzajDzialania = '-';
            tbWynik.Text = "-";
        }

        private void bMnozenie_Click(object sender, EventArgs e)
        {
            RodzajDzialania = '*';
            tbWynik.Text = "*";
        }

        private void bDzielenie_Click(object sender, EventArgs e)
        {
            RodzajDzialania = '/';
            tbWynik.Text = "/";
        }

        private void bModulo_Click(object sender, EventArgs e)
        {
            RodzajDzialania = '%';
            tbWynik.Text = "%";
        }

        private void bClear_Click(object sender, EventArgs e)
        {
            tbWynik.Text = "";
            LiczbaPierwsza = "";
            LiczbaDruga = "";
            RodzajDzialania = ' ';
        }

        private void bBack_Click(object sender, EventArgs e)
        {
            if(tbWynik.Text.Length > 0)
            {
                tbWynik.Text = tbWynik.Text.Remove(tbWynik.Text.Length -1, 1);
            }
        }

        private void bPrzecinek_Click(object sender, EventArgs e)
        {
            tbWynik.Text += ',';
        }

        private void bWynik_Click(object sender, EventArgs e)
        {
            switch(RodzajDzialania)
            {
                case ('+'):
                    tbWynik.Text = (float.Parse(LiczbaPierwsza) + float.Parse(LiczbaDruga)).ToString();
                    break;
                case ('-'):
                    tbWynik.Text = (float.Parse(LiczbaPierwsza) - float.Parse(LiczbaDruga)).ToString();
                    break;
                case ('*'):
                    //Z jakiegoś powodu wykrzacza mi się mnożenie i dzielenie floatów.
                    tbWynik.Text = (float.Parse(LiczbaPierwsza) * float.Parse(LiczbaDruga)).ToString();
                    break;
                case ('/'):
                    {
                        if (LiczbaDruga == "0")
                        {
                            tbWynik.Text = "Nie dziel przez 0!";
                        }
                        else
                        {
                            tbWynik.Text = (double.Parse(LiczbaPierwsza) / double.Parse(LiczbaDruga)).ToString();
                        }
                        break;
                    }
                case ('%'):
                    tbWynik.Text = (float.Parse(LiczbaPierwsza) % float.Parse(LiczbaDruga)).ToString();
                    break;
            }
            
            LiczbaPierwsza = "";
            LiczbaDruga = "";
            RodzajDzialania = ' ';
        }

        private void tbWynik_TextChanged(object sender, EventArgs e)
        {

        }

        private void dzialanie(float liczba)
        {
            if (RodzajDzialania == ' ')
            {
                LiczbaPierwsza = tbWynik.Text + liczba;
                tbWynik.Text = LiczbaPierwsza;
            }
            else
            {
                LiczbaDruga = tbWynik.Text + liczba;
                tbWynik.Text = LiczbaDruga;
            }
        }
        //================================================================================================================
        //================================================================================================================

        string LiczbaPierwsza1, LiczbaDruga1;

        private void bb1_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "1";
            
        }

        private void bb2_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "2";
        }

        private void bb3_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "3";
        }

        private void bb4_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "4";
        }

        private void bb5_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "5";
        }

        private void bb6_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "6";
        }

        private void bb7_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "7";
        }

        private void bb8_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "8";
        }

        private void bb9_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "9";
        }

        private void bb0_Click(object sender, EventArgs e)
        {
            tbbWynik.Text += "0";
        }

        private void bbClear_Click(object sender, EventArgs e)
        {
            LiczbaPierwsza1 = "";
            LiczbaDruga1 = "";
            tbbWynik.Text = "";
        }

        private void bbBin_Click(object sender, EventArgs e)
        {
            string wynik = "";

            int liczba = Convert.ToInt32(tbbWynik.Text);

            //Próbowałem machnąć tą binarkę, ale nie do końca poszło

            while ((liczba % 2) != 1)
            {
                if (liczba % 2 == 0)
                {
                    wynik += 0;
                }
                else
                {
                    wynik += 1;
                }
                liczba = liczba / 2;
            }

                tbbWynik.Text = wynik;

          
        }

        private void bbHex_Click(object sender, EventArgs e)
        {
            
        }

        private void tbbWynik_TextChanged(object sender, EventArgs e)
        {

        }

       


    }
}
