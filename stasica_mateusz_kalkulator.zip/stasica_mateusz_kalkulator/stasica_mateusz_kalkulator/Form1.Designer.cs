﻿namespace stasica_mateusz_kalkulator
{
    partial class Kalkulator
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.bWynik = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.bPrzecinek = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.bDzielenie = new System.Windows.Forms.Button();
            this.bDodawanie = new System.Windows.Forms.Button();
            this.bMnozenie = new System.Windows.Forms.Button();
            this.bOdejmowanie = new System.Windows.Forms.Button();
            this.bModulo = new System.Windows.Forms.Button();
            this.bClear = new System.Windows.Forms.Button();
            this.bBack = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tbWynik = new System.Windows.Forms.TextBox();
            this.bb1 = new System.Windows.Forms.Button();
            this.bb2 = new System.Windows.Forms.Button();
            this.bb3 = new System.Windows.Forms.Button();
            this.bb4 = new System.Windows.Forms.Button();
            this.bb7 = new System.Windows.Forms.Button();
            this.bb5 = new System.Windows.Forms.Button();
            this.bb6 = new System.Windows.Forms.Button();
            this.bb8 = new System.Windows.Forms.Button();
            this.bb9 = new System.Windows.Forms.Button();
            this.bb0 = new System.Windows.Forms.Button();
            this.bbClear = new System.Windows.Forms.Button();
            this.bbBin = new System.Windows.Forms.Button();
            this.bbHex = new System.Windows.Forms.Button();
            this.tbbWynik = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // b1
            // 
            this.b1.Location = new System.Drawing.Point(44, 75);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(55, 40);
            this.b1.TabIndex = 0;
            this.b1.Text = "1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.b1_Click);
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(105, 75);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(55, 40);
            this.b2.TabIndex = 1;
            this.b2.Text = "2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.b2_Click);
            // 
            // b3
            // 
            this.b3.Location = new System.Drawing.Point(166, 75);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(55, 40);
            this.b3.TabIndex = 2;
            this.b3.Text = "3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.b3_Click);
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(44, 121);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(55, 40);
            this.b4.TabIndex = 3;
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.b4_Click);
            // 
            // b5
            // 
            this.b5.Location = new System.Drawing.Point(105, 121);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(55, 40);
            this.b5.TabIndex = 4;
            this.b5.Text = "5";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.b5_Click);
            // 
            // b6
            // 
            this.b6.Location = new System.Drawing.Point(166, 121);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(55, 40);
            this.b6.TabIndex = 5;
            this.b6.Text = "6";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.b6_Click);
            // 
            // b7
            // 
            this.b7.Location = new System.Drawing.Point(44, 167);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(55, 40);
            this.b7.TabIndex = 6;
            this.b7.Text = "7";
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.b7_Click);
            // 
            // bWynik
            // 
            this.bWynik.Location = new System.Drawing.Point(44, 213);
            this.bWynik.Name = "bWynik";
            this.bWynik.Size = new System.Drawing.Size(55, 40);
            this.bWynik.TabIndex = 7;
            this.bWynik.Text = "=";
            this.bWynik.UseVisualStyleBackColor = true;
            this.bWynik.Click += new System.EventHandler(this.bWynik_Click);
            // 
            // b8
            // 
            this.b8.Location = new System.Drawing.Point(105, 167);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(55, 40);
            this.b8.TabIndex = 7;
            this.b8.Text = "8";
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.b8_Click);
            // 
            // b9
            // 
            this.b9.Location = new System.Drawing.Point(166, 167);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(55, 40);
            this.b9.TabIndex = 8;
            this.b9.Text = "9";
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.b9_Click);
            // 
            // bPrzecinek
            // 
            this.bPrzecinek.Location = new System.Drawing.Point(105, 213);
            this.bPrzecinek.Name = "bPrzecinek";
            this.bPrzecinek.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bPrzecinek.Size = new System.Drawing.Size(55, 40);
            this.bPrzecinek.TabIndex = 9;
            this.bPrzecinek.Text = ",";
            this.bPrzecinek.UseVisualStyleBackColor = true;
            this.bPrzecinek.Click += new System.EventHandler(this.bPrzecinek_Click);
            // 
            // b0
            // 
            this.b0.Location = new System.Drawing.Point(166, 213);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(55, 40);
            this.b0.TabIndex = 10;
            this.b0.Text = "0";
            this.b0.UseVisualStyleBackColor = true;
            this.b0.Click += new System.EventHandler(this.b0_Click);
            // 
            // bDzielenie
            // 
            this.bDzielenie.Location = new System.Drawing.Point(227, 213);
            this.bDzielenie.Name = "bDzielenie";
            this.bDzielenie.Size = new System.Drawing.Size(55, 40);
            this.bDzielenie.TabIndex = 11;
            this.bDzielenie.Text = "/";
            this.bDzielenie.UseVisualStyleBackColor = true;
            this.bDzielenie.Click += new System.EventHandler(this.bDzielenie_Click);
            // 
            // bDodawanie
            // 
            this.bDodawanie.Location = new System.Drawing.Point(227, 75);
            this.bDodawanie.Name = "bDodawanie";
            this.bDodawanie.Size = new System.Drawing.Size(55, 40);
            this.bDodawanie.TabIndex = 12;
            this.bDodawanie.Text = "+";
            this.bDodawanie.UseVisualStyleBackColor = true;
            this.bDodawanie.Click += new System.EventHandler(this.bDodawanie_Click);
            // 
            // bMnozenie
            // 
            this.bMnozenie.Location = new System.Drawing.Point(227, 167);
            this.bMnozenie.Name = "bMnozenie";
            this.bMnozenie.Size = new System.Drawing.Size(55, 40);
            this.bMnozenie.TabIndex = 12;
            this.bMnozenie.Text = "*";
            this.bMnozenie.UseVisualStyleBackColor = true;
            this.bMnozenie.Click += new System.EventHandler(this.bMnozenie_Click);
            // 
            // bOdejmowanie
            // 
            this.bOdejmowanie.Location = new System.Drawing.Point(227, 121);
            this.bOdejmowanie.Name = "bOdejmowanie";
            this.bOdejmowanie.Size = new System.Drawing.Size(55, 40);
            this.bOdejmowanie.TabIndex = 13;
            this.bOdejmowanie.Text = "-";
            this.bOdejmowanie.UseVisualStyleBackColor = true;
            this.bOdejmowanie.Click += new System.EventHandler(this.bOdejmowanie_Click);
            // 
            // bModulo
            // 
            this.bModulo.Location = new System.Drawing.Point(288, 75);
            this.bModulo.Name = "bModulo";
            this.bModulo.Size = new System.Drawing.Size(55, 40);
            this.bModulo.TabIndex = 14;
            this.bModulo.Text = "%";
            this.bModulo.UseVisualStyleBackColor = true;
            this.bModulo.Click += new System.EventHandler(this.bModulo_Click);
            // 
            // bClear
            // 
            this.bClear.Location = new System.Drawing.Point(288, 121);
            this.bClear.Name = "bClear";
            this.bClear.Size = new System.Drawing.Size(55, 40);
            this.bClear.TabIndex = 15;
            this.bClear.Text = "C";
            this.bClear.UseVisualStyleBackColor = true;
            this.bClear.Click += new System.EventHandler(this.bClear_Click);
            // 
            // bBack
            // 
            this.bBack.Location = new System.Drawing.Point(288, 167);
            this.bBack.Name = "bBack";
            this.bBack.Size = new System.Drawing.Size(55, 40);
            this.bBack.TabIndex = 16;
            this.bBack.Text = "<-";
            this.bBack.UseVisualStyleBackColor = true;
            this.bBack.Click += new System.EventHandler(this.bBack_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // tbWynik
            // 
            this.tbWynik.Location = new System.Drawing.Point(44, 259);
            this.tbWynik.Name = "tbWynik";
            this.tbWynik.Size = new System.Drawing.Size(299, 20);
            this.tbWynik.TabIndex = 18;
            this.tbWynik.TextChanged += new System.EventHandler(this.tbWynik_TextChanged);
            // 
            // bb1
            // 
            this.bb1.Location = new System.Drawing.Point(453, 110);
            this.bb1.Name = "bb1";
            this.bb1.Size = new System.Drawing.Size(55, 40);
            this.bb1.TabIndex = 19;
            this.bb1.Text = "1";
            this.bb1.UseVisualStyleBackColor = true;
            this.bb1.Click += new System.EventHandler(this.bb1_Click);
            // 
            // bb2
            // 
            this.bb2.Location = new System.Drawing.Point(514, 110);
            this.bb2.Name = "bb2";
            this.bb2.Size = new System.Drawing.Size(55, 40);
            this.bb2.TabIndex = 20;
            this.bb2.Text = "2";
            this.bb2.UseVisualStyleBackColor = true;
            this.bb2.Click += new System.EventHandler(this.bb2_Click);
            // 
            // bb3
            // 
            this.bb3.Location = new System.Drawing.Point(575, 110);
            this.bb3.Name = "bb3";
            this.bb3.Size = new System.Drawing.Size(55, 40);
            this.bb3.TabIndex = 21;
            this.bb3.Text = "3";
            this.bb3.UseVisualStyleBackColor = true;
            this.bb3.Click += new System.EventHandler(this.bb3_Click);
            // 
            // bb4
            // 
            this.bb4.Location = new System.Drawing.Point(453, 156);
            this.bb4.Name = "bb4";
            this.bb4.Size = new System.Drawing.Size(55, 40);
            this.bb4.TabIndex = 22;
            this.bb4.Text = "4";
            this.bb4.UseVisualStyleBackColor = true;
            this.bb4.Click += new System.EventHandler(this.bb4_Click);
            // 
            // bb7
            // 
            this.bb7.Location = new System.Drawing.Point(453, 202);
            this.bb7.Name = "bb7";
            this.bb7.Size = new System.Drawing.Size(55, 40);
            this.bb7.TabIndex = 23;
            this.bb7.Text = "7";
            this.bb7.UseVisualStyleBackColor = true;
            this.bb7.Click += new System.EventHandler(this.bb7_Click);
            // 
            // bb5
            // 
            this.bb5.Location = new System.Drawing.Point(514, 156);
            this.bb5.Name = "bb5";
            this.bb5.Size = new System.Drawing.Size(55, 40);
            this.bb5.TabIndex = 23;
            this.bb5.Text = "5";
            this.bb5.UseVisualStyleBackColor = true;
            this.bb5.Click += new System.EventHandler(this.bb5_Click);
            // 
            // bb6
            // 
            this.bb6.Location = new System.Drawing.Point(575, 156);
            this.bb6.Name = "bb6";
            this.bb6.Size = new System.Drawing.Size(55, 40);
            this.bb6.TabIndex = 24;
            this.bb6.Text = "6";
            this.bb6.UseVisualStyleBackColor = true;
            this.bb6.Click += new System.EventHandler(this.bb6_Click);
            // 
            // bb8
            // 
            this.bb8.Location = new System.Drawing.Point(514, 202);
            this.bb8.Name = "bb8";
            this.bb8.Size = new System.Drawing.Size(55, 40);
            this.bb8.TabIndex = 25;
            this.bb8.Text = "8";
            this.bb8.UseVisualStyleBackColor = true;
            this.bb8.Click += new System.EventHandler(this.bb8_Click);
            // 
            // bb9
            // 
            this.bb9.Location = new System.Drawing.Point(575, 202);
            this.bb9.Name = "bb9";
            this.bb9.Size = new System.Drawing.Size(55, 40);
            this.bb9.TabIndex = 26;
            this.bb9.Text = "9";
            this.bb9.UseVisualStyleBackColor = true;
            this.bb9.Click += new System.EventHandler(this.bb9_Click);
            // 
            // bb0
            // 
            this.bb0.Location = new System.Drawing.Point(575, 248);
            this.bb0.Name = "bb0";
            this.bb0.Size = new System.Drawing.Size(55, 40);
            this.bb0.TabIndex = 27;
            this.bb0.Text = "0";
            this.bb0.UseVisualStyleBackColor = true;
            this.bb0.Click += new System.EventHandler(this.bb0_Click);
            // 
            // bbClear
            // 
            this.bbClear.Location = new System.Drawing.Point(636, 110);
            this.bbClear.Name = "bbClear";
            this.bbClear.Size = new System.Drawing.Size(83, 40);
            this.bbClear.TabIndex = 28;
            this.bbClear.Text = "C";
            this.bbClear.UseVisualStyleBackColor = true;
            this.bbClear.Click += new System.EventHandler(this.bbClear_Click);
            // 
            // bbBin
            // 
            this.bbBin.Location = new System.Drawing.Point(636, 156);
            this.bbBin.Name = "bbBin";
            this.bbBin.Size = new System.Drawing.Size(83, 40);
            this.bbBin.TabIndex = 29;
            this.bbBin.Text = "Bin";
            this.bbBin.UseVisualStyleBackColor = true;
            this.bbBin.Click += new System.EventHandler(this.bbBin_Click);
            // 
            // bbHex
            // 
            this.bbHex.Location = new System.Drawing.Point(636, 202);
            this.bbHex.Name = "bbHex";
            this.bbHex.Size = new System.Drawing.Size(83, 40);
            this.bbHex.TabIndex = 30;
            this.bbHex.Text = "Hex";
            this.bbHex.UseVisualStyleBackColor = true;
            this.bbHex.Click += new System.EventHandler(this.bbHex_Click);
            // 
            // tbbWynik
            // 
            this.tbbWynik.Location = new System.Drawing.Point(453, 75);
            this.tbbWynik.Name = "tbbWynik";
            this.tbbWynik.Size = new System.Drawing.Size(266, 20);
            this.tbbWynik.TabIndex = 31;
            this.tbbWynik.TextChanged += new System.EventHandler(this.tbbWynik_TextChanged);
            // 
            // Kalkulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(738, 309);
            this.Controls.Add(this.tbbWynik);
            this.Controls.Add(this.bbHex);
            this.Controls.Add(this.bbBin);
            this.Controls.Add(this.bbClear);
            this.Controls.Add(this.bb0);
            this.Controls.Add(this.bb9);
            this.Controls.Add(this.bb8);
            this.Controls.Add(this.bb6);
            this.Controls.Add(this.bb5);
            this.Controls.Add(this.bb7);
            this.Controls.Add(this.bb4);
            this.Controls.Add(this.bb3);
            this.Controls.Add(this.bb2);
            this.Controls.Add(this.bb1);
            this.Controls.Add(this.tbWynik);
            this.Controls.Add(this.bBack);
            this.Controls.Add(this.bClear);
            this.Controls.Add(this.bModulo);
            this.Controls.Add(this.bOdejmowanie);
            this.Controls.Add(this.bMnozenie);
            this.Controls.Add(this.bDodawanie);
            this.Controls.Add(this.bDzielenie);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.bPrzecinek);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.bWynik);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Kalkulator";
            this.Text = "Kalkulator";
            this.Load += new System.EventHandler(this.Kalkulator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button bWynik;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button bPrzecinek;
        private System.Windows.Forms.Button b0;
        private System.Windows.Forms.Button bDzielenie;
        private System.Windows.Forms.Button bDodawanie;
        private System.Windows.Forms.Button bMnozenie;
        private System.Windows.Forms.Button bOdejmowanie;
        private System.Windows.Forms.Button bModulo;
        private System.Windows.Forms.Button bClear;
        private System.Windows.Forms.Button bBack;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox tbWynik;
        private System.Windows.Forms.Button bb1;
        private System.Windows.Forms.Button bb2;
        private System.Windows.Forms.Button bb3;
        private System.Windows.Forms.Button bb4;
        private System.Windows.Forms.Button bb7;
        private System.Windows.Forms.Button bb5;
        private System.Windows.Forms.Button bb6;
        private System.Windows.Forms.Button bb8;
        private System.Windows.Forms.Button bb9;
        private System.Windows.Forms.Button bb0;
        private System.Windows.Forms.Button bbClear;
        private System.Windows.Forms.Button bbBin;
        private System.Windows.Forms.Button bbHex;
        private System.Windows.Forms.TextBox tbbWynik;
    }
}

