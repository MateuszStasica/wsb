﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace obwod_pole
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void box1_TextChanged(object sender, EventArgs e)
        {
            double bok;
            if(double.TryParse(box1.Text, out bok) && bok>0)
            {
                box2.Text = Math.Pow(bok, 2).ToString();
                box3.Text = (4 * bok).ToString();
                label4.Text = String.Empty;
            }
            else
            {
                label4.Text = "Wpisz liczbę dodatnią";
                box2.Text = String.Empty;
                box3.Text = String.Empty;
            }
        }

        private void but1_Click(object sender, EventArgs e)
        {
            
            Application.Exit();
        }
    }
}
