﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace instrukcje_warunkowe
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            int x = -5;
            if (x > 3)
            {
                Console.WriteLine("prawda");
            }
            else if (x == 5)
            {
                Console.WriteLine("x jest równy 5");
            }
            else
            {
                Console.WriteLine("fałsz");
            }
            */


            

            Console.WriteLine("Podaj długość boku kwadratu: ");

            string y = Console.ReadLine();
            double y1;

            if (double.TryParse(y, out y1) == true)
            {
                //Jeśli się udało sparsować, wyświetlić wynik
                Console.WriteLine("Pole kwadratu o polu: "+y1+ " wynosi: "+y1*y1);
             
            }
            else
            {
                Console.WriteLine("Błędne dane");
            }

            //TRÓJKĄT
            //WPROWADZENIE WARTOSCI
            Console.WriteLine("Podaj długość podstawy trójkąta: ");
            string podstawa=Console.ReadLine();

            Console.WriteLine("Podaj wysokość trójkąta: ");
            string wysokosc = Console.ReadLine();

            double podstawa1;
            double wysokosc1;

            //SPRAWDZENIE, CZY PODANE WARTOSCI SĄ LICZBAMI
            if(double.TryParse(podstawa, out podstawa1) &&
               double.TryParse(wysokosc, out wysokosc1))
            {
                //JEŚLI TAK, TO WYPLUJE WYNIK
                Console.WriteLine("Pole trójkąta wynosi: "+(podstawa1*wysokosc1)/2);
            }
            else
            {
                //JEŚLI PODAŁEŚ LITERY TO WYPLUJE BŁĄD
                Console.WriteLine("Error!!! Błędne dane");
            }


            Console.ReadKey();
        }
    }
}
