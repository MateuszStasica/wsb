﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zajecia_2_if_10._10._2019
{
    class Program
    {
        static void Main(string[] args)
        {

            //WYŚWIETL LICZBY Z PRZEDZIAŁU

            /*
            for(int i=20;i>=1;i--)
            {
                if(i%2==0)
                Console.Write(i+" ");
            }
            */

            Console.WriteLine("Podaj dlugosc ramienia trójkąta: ");
            string dlugosc = Console.ReadLine();
            int dlugosc1;

            if(int.TryParse(dlugosc, out dlugosc1)==true)
            {
                for (int i = 1; i <= dlugosc1; i++)
                {
                    for(int j=1;j<=i;j++)
                    {
                        for(int k=i; k>=1; k--)
                        {
                            Console.Write(" ");
                        }
                        Console.Write("*");
                    }
                    Console.WriteLine("\n");
                }
            }

            

            Console.ReadKey();
        }
    }
}
