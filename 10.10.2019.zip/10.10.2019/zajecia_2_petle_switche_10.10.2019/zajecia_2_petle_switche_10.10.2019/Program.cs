﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zajecia_2_petle_switche_10._10._2019
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Witaj w kalkulatorze figur geometrycznych!\nKtórą z wypisanych poniżej figur chciałbyś obliczyć?\n1.Kwadrat\n2.Koło");

            string wybor = Console.ReadLine();
            double wybor1;

            if (double.TryParse(wybor, out wybor1) == true)
            {
                switch (wybor)
                {
                    case "1":

                        Console.WriteLine("Podaj długość boku kwadratu: ");
                        string a = Console.ReadLine();
                        double a1;                                  //SCIĄGA WARTOŚCI Z KLAWIATURY
                        if (double.TryParse(a, out a1) == true)     //SPRAWDZA, CZY PODANA WARTOŚĆ JEST LICZBĄ
                        {
                            Console.WriteLine("Pole twojego kwadratu wynosi: " + a1 * a1);
                        }
                        else Console.WriteLine("Długość podaje się w liczbach głuptasie!");
                        break;

                    case "2":

                        Console.WriteLine("Podaj długość promienia koła: ");
                        string promien = Console.ReadLine();
                        double promien1;
                        double pole;
                        if (double.TryParse(promien, out promien1) == true)
                        {
                            //WAŻNE! KLAMRA OZNACZA PRECYZJĘ LICZBY/MIEJSCA PO PRZECINKU!
                            pole=Math.PI*promien1*promien1;
                            Console.WriteLine("Pole twojego koła wynosi:{0:##.##} ",pole ); 
                        }
                        else Console.WriteLine("Długość podaje się w liczbach głuptasie!");
                        break;

                }
            }
            else Console.WriteLine("Wybór dokonaj za pomocą liczb 1-2");

            Console.ReadKey();
        }
    }
}
